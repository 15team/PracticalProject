package java8543.lesson13;

public class Exception8543_2 {
    public static void main(String[] args){
        int[] a=new int[]{101,201,301,401};
        try{
            int at=Integer.parseInt(args[0]);
            System.out.println("第"+at+"个元素="+a[at-1]);
        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("数组下标超界：" + e.toString());
        }catch (Exception e){
            System.out.println(e.toString());
        }finally {
            System.out.println("**********Exception543_2主方法结束！**********");
        }
    }

}
