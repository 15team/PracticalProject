package java8543.lesson13;
class A543{}
public class Exception8543_1 {
    public static void main(String[] args){
        try{
            Object obj=new java8543.lesson13.Exception8543_1();
            A543 a=(A543)obj;
        }catch (ClassCastException e){
            e.printStackTrace();
            System.out.println("**********ExceptionXXX_1主方法结束！**********");
        }
    }
}
