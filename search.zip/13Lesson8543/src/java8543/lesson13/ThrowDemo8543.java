package java8543.lesson13;

public class ThrowDemo8543 {
    public static void main(String[] args) {
        System.out.println("（1）用无参构造方法创建Student");
        Student8543 s = new Student8543();
        try{
            s.setAge(10);
        }catch(AgeRangeException8543 e) {
            System.out.println(e);
        }
        System.out.println("（2）用带参的构造方法创建Student");
        try {
            Student8543 b = new Student8543("小红", 40);
        }catch(AgeRangeException8543 a) {
            System.out.println(a);
        }
        System.out.println("ThrowDemo8543 结束");
    }
}
