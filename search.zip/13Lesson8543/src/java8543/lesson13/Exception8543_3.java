package java8543.lesson13;

public class Exception8543_3{
    public static void main(String[] args){
        int[] a=new int[]{101,201,301,401};
        int at=0;
        try{
            System.out.println(a[7]);
        }finally{
            System.out.println("填写finally执行原因：finally块一般都会正常运行，除非程序出现终止");
            System.out.println("填写END没有执行的原因：因为遇到异常，在执行完finally后，方法就会出现");
        }
        System.out.println("END");
    }
}
