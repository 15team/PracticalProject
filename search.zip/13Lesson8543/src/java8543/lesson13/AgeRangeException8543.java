package java8543.lesson13;

class AgeRangeException8543 extends Exception {
    public AgeRangeException8543(){

    }
    public AgeRangeException8543(String message){
        super(message);
    }
}
