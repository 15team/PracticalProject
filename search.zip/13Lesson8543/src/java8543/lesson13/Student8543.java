package java8543.lesson13;

public class Student8543 {
    private String name;
    private  int age;

    public Student8543(){}
    public Student8543(String name,int age) throws AgeRangeException8543{
        setAge(age);
        setName(name);
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) throws AgeRangeException8543{
        if(age>=12 && age<=35 ){
            this.age = age;
        }else{
            throw new AgeRangeException8543("学生的年龄应在12-35之间");
        }
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

}
